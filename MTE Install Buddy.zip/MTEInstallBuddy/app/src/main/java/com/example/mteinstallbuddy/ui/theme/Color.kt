package com.example.mteinstallbuddy.ui.theme

import androidx.compose.ui.graphics.Color

val MeyerBlue = Color(0xFF1A68C5)
val MeyerNavy = Color(0xFF004594)
val MeyerWhite = Color(0xFFFFFFFF)
val MeyerBackground = Color(0xFFFBFDFC)